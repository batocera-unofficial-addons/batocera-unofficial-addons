#!/bin/bash

# ===== BUA GitHub web registration adapter =====
bua_github_web_register() {
    local bua_owner='Vencord'
    local bua_repo='Vesktop'

    local bua_values

    bua_values=$(
        python3 - "$bua_owner" "$bua_repo" <<'PYBUAGH'
import hashlib
import html
import json
import re
import sys
import urllib.parse
import urllib.request
import xml.etree.ElementTree as ET

owner, repo = sys.argv[1:3]

UA = "Mozilla/5.0 BUA-Updater"


def request(url):
    req = urllib.request.Request(
        url,
        headers={
            "User-Agent": UA,
            "Cache-Control": "no-cache",
        },
    )

    with urllib.request.urlopen(
        req,
        timeout=25,
    ) as response:
        return (
            response.geturl(),
            response.read(),
        )


def latest_tag():
    latest_url = (
        f"https://github.com/{owner}/{repo}/"
        "releases/latest"
    )

    try:
        final_url, _ = request(latest_url)

        match = re.search(
            r"/releases/tag/([^/?#]+)",
            final_url,
        )

        if match:
            return urllib.parse.unquote(
                match.group(1)
            )

    except Exception:
        pass

    # Nightly/prerelease fallback.
    atom_url = (
        f"https://github.com/{owner}/{repo}/"
        "releases.atom"
    )

    _, body = request(atom_url)

    root = ET.fromstring(body)

    ns = {
        "atom": "http://www.w3.org/2005/Atom",
    }

    entries = root.findall(
        "atom:entry",
        ns,
    )

    for entry in entries:
        link = entry.find(
            "atom:link",
            ns,
        )

        if link is None:
            continue

        href = link.attrib.get(
            "href",
            "",
        )

        match = re.search(
            r"/releases/tag/([^/?#]+)",
            href,
        )

        if match:
            return urllib.parse.unquote(
                match.group(1)
            )

    raise RuntimeError(
        "Unable to determine GitHub release tag"
    )


def asset_fingerprint(tag):
    encoded_tag = urllib.parse.quote(
        tag,
        safe="",
    )

    url = (
        f"https://github.com/{owner}/{repo}/"
        f"releases/expanded_assets/{encoded_tag}"
    )

    _, body = request(url)

    text = html.unescape(
        body.decode(
            "utf-8",
            errors="replace",
        )
    )

    href_pattern = re.compile(
        rf'href="(/'
        rf'{re.escape(owner)}/'
        rf'{re.escape(repo)}/'
        r'releases/download/[^"]+)"',
        re.I,
    )

    hrefs = sorted(
        set(
            href_pattern.findall(text)
        )
    )

    datetimes = sorted(
        set(
            re.findall(
                r'datetime="([^"]+)"',
                text,
                re.I,
            )
        )
    )

    sizes = sorted(
        set(
            re.findall(
                r'([0-9]+(?:\.[0-9]+)?\s*'
                r'(?:Bytes|KB|MB|GB|KiB|MiB|GiB))',
                text,
                re.I,
            )
        )
    )

    payload = {
        "owner": owner,
        "repo": repo,
        "tag": tag,
        "assets": hrefs,
        "datetimes": datetimes,
        "sizes": sizes,
    }

    encoded = json.dumps(
        payload,
        sort_keys=True,
        separators=(",", ":"),
    ).encode("utf-8")

    return hashlib.sha256(
        encoded
    ).hexdigest()


tag = latest_tag()

digest = asset_fingerprint(
    tag
)

identity = (
    "github-web:"
    + tag
    + ":"
    + digest
)

print(tag)
print(identity)
PYBUAGH
    ) || return 1

    local bua_version
    local bua_identity

    bua_version=$(
        printf '%s\n' "$bua_values" |
            sed -n '1p'
    )

    bua_identity=$(
        printf '%s\n' "$bua_values" |
            sed -n '2p'
    )

    if [[ -z "$bua_version" || -z "$bua_identity" ]]; then
        echo "Unable to determine GitHub release identity." >&2
        return 1
    fi

    bua_register \
        "$bua_version" \
        "github_release" \
        "$bua_owner" \
        "$bua_repo" \
        "custom" \
        "" \
        "" \
        "" \
        "$bua_identity"
}

if [[ "${BUA_REGISTRATION_ONLY:-0}" == "1" ]]; then
    if ! declare -F bua_register >/dev/null 2>&1; then
        echo "BUA registration helper unavailable." >&2
        exit 1
    fi

    bua_github_web_register
    exit $?
fi
# ===== end BUA GitHub web registration adapter =====


# Step 1: Detect system architecture
echo "Detecting system architecture..."
arch=$(uname -m)

LATEST=$(curl -s https://api.github.com/repos/Vencord/Vesktop/releases/latest | grep '"tag_name"' | cut -d'"' -f4)
if [ "$arch" == "x86_64" ]; then
    echo "Architecture: x86_64 detected."
    appimage_url="https://github.com/Vencord/Vesktop/releases/download/${LATEST}/Vesktop-${LATEST#v}.AppImage"
elif [ "$arch" == "aarch64" ]; then
    echo "Architecture: arm64 detected."
    appimage_url="https://github.com/Vencord/Vesktop/releases/download/${LATEST}/Vesktop-${LATEST#v}-arm64.AppImage"
else
    echo "Unsupported architecture: $arch. Exiting."
    exit 1
fi

# Step 2: Download the AppImage
echo "Downloading Vesktop AppImage from $appimage_url..."
mkdir -p /userdata/system/add-ons/vesktop
wget -q --show-progress -O /userdata/system/add-ons/vesktop/Vesktop.AppImage "$appimage_url"

if [ $? -ne 0 ]; then
    echo "Failed to download the Vesktop AppImage."
    exit 1
fi

chmod a+x /userdata/system/add-ons/vesktop/Vesktop.AppImage
echo "Vesktop AppImage downloaded and marked as executable."

# Create persistent configuration and log directories
mkdir -p /userdata/system/logs
mkdir -p /userdata/system/configs/vesktop
mkdir -p /userdata/system/add-ons/vesktop/extra
DESKTOP_FILE="/usr/share/applications/Vesktop.desktop"
PERSISTENT_DESKTOP="/userdata/system/configs/vesktop/Vesktop.desktop"
ICON_URL="https://github.com/batocera-unofficial-addons/batocera-unofficial-addons/raw/main/vesktop/extra/icon.png"
INSTALL_DIR="/userdata/system/add-ons/vesktop"

# Step 3: Create the Vesktop Launcher Script
echo "Creating Vesktop launcher script in Ports..."
mkdir -p /userdata/roms/ports
cat << 'EOF' > /userdata/roms/ports/Vesktop.sh
#!/bin/bash
export HOME=/userdata/system/add-ons/vesktop

# Function to ensure the quickCss.css file exists
ensure_quick_css() {
    config_settings_dir="${HOME}/.config/vesktop/settings"
    quickCss="${config_settings_dir}/quickCss.css"

    # Ensure the .config/vesktop/settings directory exists
    mkdir -p "$config_settings_dir"

    # Ensure quickCss.css exists (you can create an empty file or add some default content)
    if [ ! -f "$quickCss" ]; then
        echo "/* Default CSS for Vesktop */" > "$quickCss"
        echo "$(date): Created default quickCss.css."
    fi
}

# Call functions
ensure_quick_css

# Environment setup
export $(cat /proc/1/environ | tr '\0' '\n')
export DISPLAY=:0

# Directories and file paths
app_dir="/userdata/system/add-ons/vesktop"
app_image="${app_dir}/Vesktop.AppImage"
log_dir="/userdata/system/logs"
log_file="${log_dir}/vesktop.log"

# Ensure log directory exists
mkdir -p "${log_dir}"

# Append all output to the log file
exec &> >(tee -a "$log_file")
echo "$(date): Launching Vesktop"

# Launch Vesktop AppImage
if [ -x "$app_image" ]; then
    echo "$(date): AppImage is executable, launching..."
    cd "$app_dir"
    ./Vesktop.AppImage --no-sandbox --trace-warnings > "$log_file" 2>&1
    echo "$(date): Vesktop exited."
else
    echo "$(date): Vesktop.AppImage not found or not executable."
    exit 1
fi

EOF

chmod +x /userdata/roms/ports/Vesktop.sh

echo "Downloading icon..."
wget --show-progress -qO "${INSTALL_DIR}/extra/icon.png" "$ICON_URL"

# Create persistent desktop entry
echo "Creating persistent desktop entry for Vesktop..."
cat <<EOF > "$PERSISTENT_DESKTOP"
[Desktop Entry]
Version=1.0
Type=Application
Name=Vesktop
Exec=/userdata/roms/ports/Vesktop.sh
Icon=/userdata/system/add-ons/vesktop/extra/icon.png
Terminal=false
Categories=Game;batocera.linux;
EOF

chmod +x "$PERSISTENT_DESKTOP"

cp "$PERSISTENT_DESKTOP" "$DESKTOP_FILE"
chmod +x "$DESKTOP_FILE"

# Ensure the desktop entry is always restored to /usr/share/applications
echo "Ensuring Vesktop desktop entry is restored at startup..."
cat <<EOF > "/userdata/system/configs/vesktop/restore_desktop_entry.sh"
#!/bin/bash
# Restore Vesktop desktop entry
if [ ! -f "$DESKTOP_FILE" ]; then
    echo "Restoring Vesktop desktop entry..."
    cp "$PERSISTENT_DESKTOP" "$DESKTOP_FILE"
    chmod +x "$DESKTOP_FILE"
    echo "Vesktop desktop entry restored."
else
    echo "Vesktop desktop entry already exists."
fi
EOF
chmod +x "/userdata/system/configs/vesktop/restore_desktop_entry.sh"

# Add to startup script
custom_startup="/userdata/system/custom.sh"
if ! grep -q "/userdata/system/configs/vesktop/restore_desktop_entry.sh" "$custom_startup"; then
    echo "Adding Vesktop restore script to startup..."
    echo "bash "/userdata/system/configs/vesktop/restore_desktop_entry.sh" &" >> "$custom_startup"
fi
chmod +x "$custom_startup"

echo "Refreshing Ports menu..."
curl http://127.0.0.1:1234/reloadgames

KEYS_URL="https://raw.githubusercontent.com/batocera-unofficial-addons/batocera-unofficial-addons/refs/heads/main/netflix/extra/Netflix.sh.keys"
# Step 5: Download the key mapping file
echo "Downloading key mapping file..."
curl -L -o "/userdata/roms/ports/Vesktop.sh.keys" "$KEYS_URL"
# Download the image
echo "Downloading Vesktop logo..."
curl -L -o /userdata/roms/ports/images/vesktoplogo.png https://github.com/batocera-unofficial-addons/batocera-unofficial-addons/raw/main/vesktop/extra/vesktoplogo.png

echo "Adding logo to Vesktop entry in gamelist.xml..."
xmlstarlet ed -s "/gameList" -t elem -n "game" -v "" \
  -s "/gameList/game[last()]" -t elem -n "path" -v "./Vesktop.sh" \
  -s "/gameList/game[last()]" -t elem -n "name" -v "Vesktop" \
  -s "/gameList/game[last()]" -t elem -n "image" -v "./images/vesktoplogo.png" \
  /userdata/roms/ports/gamelist.xml > /userdata/roms/ports/gamelist.xml.tmp && mv /userdata/roms/ports/gamelist.xml.tmp /userdata/roms/ports/gamelist.xml


curl http://127.0.0.1:1234/reloadgames

echo
echo "Installation complete! You can now launch Vesktop from the Ports menu."


# ===== BUA post-install registration =====
if declare -F bua_register >/dev/null 2>&1; then
    bua_github_web_register || true
fi
# ===== end BUA post-install registration =====

