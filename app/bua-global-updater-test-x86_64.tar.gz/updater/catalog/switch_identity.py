#!/usr/bin/env python3

import hashlib
import json
import re
import subprocess
import urllib.request


def get_bytes(url):
    req = urllib.request.Request(
        url,
        headers={
            "User-Agent": "BUA-Updater",
            "Cache-Control": "no-cache",
        },
    )

    with urllib.request.urlopen(
        req,
        timeout=25,
    ) as response:
        return response.read()


result = subprocess.run(
    ["batocera-es-swissknife", "--version"],
    stdout=subprocess.PIPE,
    stderr=subprocess.PIPE,
    text=True,
    timeout=10,
)

m = re.search(
    r"^([0-9]+)",
    result.stdout.strip(),
)

if not m:
    raise SystemExit(
        "Unable to determine Batocera major version"
    )

major = int(m.group(1))

if major not in (42, 43, 44):
    raise SystemExit(
        f"Component identity not supported for Batocera {major}"
    )


components = []


# ============================================================
# Citron
# ============================================================

html = get_bytes(
    "https://github.com/NextendoNetwork/"
    "citron-nextendo/releases/expanded_assets/nightly-linux"
).decode("utf-8", "replace")

m = re.search(
    r'/NextendoNetwork/citron-nextendo/releases/download/'
    r'nightly-linux/'
    r'(citron_nightly-([0-9a-f]+)-linux-x86_64_v3\.AppImage)',
    html,
)

if not m:
    raise SystemExit("Unable to resolve Citron")

citron_url = "https://github.com" + m.group(0)
citron_version = "nightly-" + m.group(2)

components.append({
    "name": "Citron",
    "version": citron_version,
    "url": citron_url,
    "target": (
        "/userdata/system/switch/appimages/"
        "citron-emu.AppImage"
    ),
})


# ============================================================
# Eden stable + PGO
# ============================================================

eden_data = json.loads(
    get_bytes(
        "https://stable.eden-emu.dev/latest/release.json"
    ).decode("utf-8")
)

eden_version = str(
    eden_data.get("tag_name") or ""
).strip()

eden_base = str(
    eden_data.get("base")
    or "https://stable.eden-emu.dev"
).rstrip("/")

if not eden_version:
    raise SystemExit("Unable to resolve Eden")

eden_url = (
    f"{eden_base}/{eden_version}/"
    f"Eden-Linux-{eden_version}-"
    "amd64-gcc-standard.AppImage"
)

eden_pgo_url = (
    f"{eden_base}/{eden_version}/"
    f"Eden-Linux-{eden_version}-"
    "amd64-clang-pgo.AppImage"
)

components.append({
    "name": "Eden",
    "version": eden_version,
    "url": eden_url,
    "target": (
        "/userdata/system/switch/appimages/"
        "eden-emu.AppImage"
    ),
})

components.append({
    "name": "Eden PGO",
    "version": eden_version,
    "url": eden_pgo_url,
    "target": (
        "/userdata/system/switch/appimages/"
        "eden-pgo.AppImage"
    ),
})


# ============================================================
# Eden Nightly
# ============================================================

nightly_data = json.loads(
    get_bytes(
        "https://nightly.eden-emu.dev/latest/release.json"
    ).decode("utf-8")
)

nightly_version = str(
    nightly_data.get("tag_name") or ""
).strip()

nightly_base = str(
    nightly_data.get("base")
    or "https://nightly.eden-emu.dev"
).rstrip("/")

if (
    not nightly_version
    or "." not in nightly_version
):
    raise SystemExit("Unable to resolve Eden Nightly")

nightly_short = nightly_version.split(".", 1)[1]

nightly_url = (
    f"{nightly_base}/{nightly_version}/"
    f"Eden-Linux-{nightly_short}-"
    "amd64-gcc-standard.AppImage"
)

components.append({
    "name": "Eden Nightly",
    "version": nightly_version,
    "url": nightly_url,
    "target": (
        "/userdata/system/switch/appimages/"
        "eden-nightly.AppImage"
    ),
})


# ============================================================
# Composite identity
# ============================================================

identity_payload = {
    "batocera_major": major,
    "components": components,
}

serialized = json.dumps(
    identity_payload,
    sort_keys=True,
    separators=(",", ":"),
).encode("utf-8")

digest = hashlib.sha256(
    serialized
).hexdigest()

display_version = (
    f"Citron {citron_version}; "
    f"Eden {eden_version}; "
    f"Nightly {nightly_version}"
)

print(display_version)
print(
    "switch:"
    + str(major)
    + ":components:"
    + digest
)
print("multi_parent")
print("switch-components")
print(json.dumps(
    components,
    separators=(",", ":"),
))
