#!/usr/bin/env python3

from pathlib import Path
import json
import os
import shutil
import subprocess
import sys

CONFIG = Path("/userdata/system/configs/bua/nextendo-browser.json")

URL = sys.argv[1] if len(sys.argv) > 1 else ""

if not URL.startswith(("http://", "https://")):
    raise SystemExit(2)


def add_browser(items, name, command):
    key = tuple(command)

    if any(tuple(x["command"]) == key for x in items):
        return

    items.append({
        "name": name,
        "command": command,
    })


def detect_browsers():
    browsers = []

    # Common BUA / AppImage browsers.
    appimage_candidates = [
        ("Firefox", "/userdata/system/add-ons/firefox/Firefox.AppImage"),
        ("LibreWolf", "/userdata/system/add-ons/librewolf/LibreWolf.AppImage"),
        ("Floorp", "/userdata/system/add-ons/floorp/Floorp.AppImage"),
        ("Chromium", "/userdata/system/add-ons/chromium/Chromium.AppImage"),
        ("Brave", "/userdata/system/add-ons/brave/Brave.AppImage"),
        ("Google Chrome", "/userdata/system/add-ons/chrome/Chrome.AppImage"),
        ("Vivaldi", "/userdata/system/add-ons/vivaldi/Vivaldi.AppImage"),
        ("Opera", "/userdata/system/add-ons/opera/Opera.AppImage"),
    ]

    for name, path in appimage_candidates:
        p = Path(path)
        if p.is_file() and os.access(p, os.X_OK):
            add_browser(browsers, name, [str(p)])

    # Other browser AppImages under BUA add-ons.
    root = Path("/userdata/system/add-ons")

    if root.is_dir():
        names = {
            "firefox": "Firefox",
            "librewolf": "LibreWolf",
            "floorp": "Floorp",
            "chromium": "Chromium",
            "chrome": "Google Chrome",
            "brave": "Brave",
            "vivaldi": "Vivaldi",
            "opera": "Opera",
        }

        for p in root.rglob("*.AppImage"):
            low = p.name.lower()

            for token, display in names.items():
                if token in low and os.access(p, os.X_OK):
                    add_browser(browsers, display, [str(p)])
                    break

    # Native executables if present.
    native = [
        ("Firefox", "firefox"),
        ("LibreWolf", "librewolf"),
        ("Floorp", "floorp"),
        ("Chromium", "chromium"),
        ("Chromium", "chromium-browser"),
        ("Google Chrome", "google-chrome"),
        ("Brave", "brave-browser"),
        ("Vivaldi", "vivaldi"),
        ("Opera", "opera"),
    ]

    for name, exe in native:
        found = shutil.which(exe)
        if found:
            add_browser(browsers, name, [found])

    # Flatpak browsers.
    flatpaks = [
        ("Firefox", "org.mozilla.firefox"),
        ("Chromium", "org.chromium.Chromium"),
        ("Google Chrome", "com.google.Chrome"),
        ("Brave", "com.brave.Browser"),
        ("LibreWolf", "io.gitlab.librewolf-community"),
        ("Vivaldi", "com.vivaldi.Vivaldi"),
    ]

    if shutil.which("flatpak"):
        try:
            installed = subprocess.check_output(
                ["flatpak", "list", "--columns=application"],
                text=True,
                stderr=subprocess.DEVNULL,
            ).splitlines()

            installed = set(x.strip() for x in installed)

            for name, appid in flatpaks:
                if appid in installed:
                    add_browser(
                        browsers,
                        name + " (Flatpak)",
                        ["flatpak", "run", appid],
                    )
        except Exception:
            pass

    return browsers


def load_saved(browsers):
    try:
        data = json.loads(CONFIG.read_text(encoding="utf-8"))
        command = data.get("command")

        if not isinstance(command, list):
            return None

        for browser in browsers:
            if browser["command"] == command:
                return browser

    except Exception:
        pass

    return None


def save_browser(browser):
    CONFIG.parent.mkdir(parents=True, exist_ok=True)

    CONFIG.write_text(
        json.dumps(browser, indent=2) + "\n",
        encoding="utf-8",
    )


def choose_with_pygame(browsers):
    import pygame

    os.environ.setdefault("DISPLAY", ":0")
    os.environ.setdefault("XAUTHORITY", "/.Xauthority")

    pygame.init()
    pygame.joystick.init()

    screen = pygame.display.set_mode((760, 420))
    pygame.display.set_caption("NexTendo Browser Selection")

    font = pygame.font.Font(None, 38)
    small = pygame.font.Font(None, 28)

    selected = 0
    clock = pygame.time.Clock()

    while True:
        screen.fill((24, 24, 24))

        title = font.render(
            "Choose browser for NexTendo sign-in",
            True,
            (240, 240, 240),
        )
        screen.blit(title, (40, 35))

        subtitle = small.render(
            "Use Up/Down and Enter/A",
            True,
            (180, 180, 180),
        )
        screen.blit(subtitle, (40, 80))

        y = 135

        for i, browser in enumerate(browsers):
            if i == selected:
                pygame.draw.rect(
                    screen,
                    (70, 100, 170),
                    (30, y - 8, 700, 48),
                    border_radius=8,
                )

            txt = small.render(
                browser["name"],
                True,
                (255, 255, 255),
            )
            screen.blit(txt, (50, y))

            y += 55

        pygame.display.flip()

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                raise SystemExit(1)

            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_UP:
                    selected = (selected - 1) % len(browsers)

                elif event.key == pygame.K_DOWN:
                    selected = (selected + 1) % len(browsers)

                elif event.key in (
                    pygame.K_RETURN,
                    pygame.K_KP_ENTER,
                    pygame.K_SPACE,
                ):
                    pygame.quit()
                    return browsers[selected]

                elif event.key == pygame.K_ESCAPE:
                    pygame.quit()
                    raise SystemExit(1)

            if event.type == pygame.JOYHATMOTION:
                if event.value[1] > 0:
                    selected = (selected - 1) % len(browsers)

                elif event.value[1] < 0:
                    selected = (selected + 1) % len(browsers)

            if event.type == pygame.JOYBUTTONDOWN:
                # Accept common A-button positions.
                if event.button in (0, 1):
                    pygame.quit()
                    return browsers[selected]

        clock.tick(30)


def launch(browser):
    log = open(
        "/tmp/nextendo-browser.log",
        "ab",
        buffering=0,
    )

    env = os.environ.copy()
    env["DISPLAY"] = ":0"
    env["XAUTHORITY"] = "/.Xauthority"

    subprocess.Popen(
        browser["command"] + [URL],
        stdin=subprocess.DEVNULL,
        stdout=log,
        stderr=log,
        start_new_session=True,
        env=env,
    )


browsers = detect_browsers()

if not browsers:
    print("[Nextendo] No supported web browser detected.", file=sys.stderr)
    raise SystemExit(1)

browser = load_saved(browsers)

if browser is None:
    if len(browsers) == 1:
        browser = browsers[0]
    else:
        browser = choose_with_pygame(browsers)

    save_browser(browser)

print(f"[Nextendo] Browser: {browser['name']}")
launch(browser)
