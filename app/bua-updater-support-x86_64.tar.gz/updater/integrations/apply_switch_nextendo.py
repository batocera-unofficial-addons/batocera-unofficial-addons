#!/usr/bin/env python3

from pathlib import Path
import py_compile
import xml.etree.ElementTree as ET

FEATURES = Path(
    "/userdata/system/configs/emulationstation/es_features_switch.cfg"
)

GENERATOR = Path(
    "/userdata/system/switch/configgen/generators/edenGenerator.py"
)

FEATURE_VALUE = "nextendo_network"


def patch_features():
    if not FEATURES.is_file():
        print("[Nextendo] Switch feature file not installed; skipping.")
        return False

    text = FEATURES.read_text(encoding="utf-8")

    if f'value="{FEATURE_VALUE}"' in text:
        print("[Nextendo] Advanced Game Settings feature already present.")
        return False

    start = text.find('<emulator name="citron-emu"')
    if start == -1:
        print("[Nextendo] citron-emu feature block not present; skipping.")
        return False

    end = text.find("</emulator>", start)
    if end == -1:
        raise RuntimeError("citron-emu feature block is malformed")

    block = text[start:end]

    anchor = (
        '    <sharedFeature value="hud_corner" '
        'group="SWITCH OPTIONS" submenu="DISPLAY" />'
    )

    if anchor not in block:
        raise RuntimeError("citron-emu insertion anchor not found")

    addition = '''\
    <feature name="NEXTENDO NETWORK" group="SWITCH OPTIONS" submenu="NETWORK" value="nextendo_network" description="Enable NexTendo network redirection for supported games.">
      <choice name="Disabled" value="false" />
      <choice name="Enabled" value="true" />
    </feature>'''

    block = block.replace(
        anchor,
        anchor + "\n" + addition,
        1,
    )

    new_text = text[:start] + block + text[end:]

    # Validate XML before replacing the live file.
    ET.fromstring(new_text)

    tmp = FEATURES.with_suffix(FEATURES.suffix + ".bua-nextendo.tmp")
    tmp.write_text(new_text, encoding="utf-8")
    tmp.replace(FEATURES)

    print("[Nextendo] Added Citron Advanced Game Settings feature.")
    return True


def patch_generator():
    if not GENERATOR.is_file():
        print("[Nextendo] Switch generator not installed; skipping.")
        return False

    text = GENERATOR.read_text(encoding="utf-8")

    if "system.isOptSet('nextendo_network')" in text:
        print("[Nextendo] Citron generator support already present.")
        return False

    anchor = '''\
    # controls section
        if not yuzuConfig.has_section("Controls"):'''

    addition = '''\
    # NexTendo network redirection - Citron only
        if emulator == "citron-emu":
            if not yuzuConfig.has_section("Network"):
                yuzuConfig.add_section("Network")

            if system.isOptSet('nextendo_network'):
                yuzuConfig.set(
                    "Network",
                    "enable_nextendo",
                    system.config["nextendo_network"]
                )
                yuzuConfig.set(
                    "Network",
                    "enable_nextendo\\\\default",
                    "false"
                )

'''

    if anchor not in text:
        raise RuntimeError("Switch generator insertion anchor not found")

    new_text = text.replace(
        anchor,
        addition + anchor,
        1,
    )

    tmp = GENERATOR.with_suffix(GENERATOR.suffix + ".bua-nextendo.tmp")
    tmp.write_text(new_text, encoding="utf-8")

    # Compile the proposed replacement before touching the live generator.
    py_compile.compile(str(tmp), doraise=True)

    tmp.replace(GENERATOR)

    print("[Nextendo] Added Citron generator support.")
    return True


def main():
    print("[Nextendo] Checking Switch/Citron integration...")
    patch_features()
    patch_generator()
    print("[Nextendo] Integration check complete.")


if __name__ == "__main__":
    main()
