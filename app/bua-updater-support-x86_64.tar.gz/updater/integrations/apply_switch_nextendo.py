#!/usr/bin/env python3

from pathlib import Path
import os
import re
import py_compile
import xml.etree.ElementTree as ET

FEATURES = Path(
    "/userdata/system/configs/emulationstation/es_features_switch.cfg"
)

GENERATOR = Path(
    "/userdata/system/switch/configgen/generators/edenGenerator.py"
)

XDG_OPEN = Path(
    "/userdata/system/switch/extra/xdgfix/xdg-open"
)

FEATURE_VALUE = "nextendo_network"


def patch_features():
    if not FEATURES.is_file():
        print("[Nextendo] Switch feature file not installed; skipping.")
        return False

    text = FEATURES.read_text(encoding="utf-8")

    if f'value="{FEATURE_VALUE}"' in text:
        print("[Nextendo] Advanced Game Settings feature already present.")
        return False

    start = text.find('<emulator name="citron-emu"')
    if start == -1:
        print("[Nextendo] citron-emu feature block not present; skipping.")
        return False

    end = text.find("</emulator>", start)
    if end == -1:
        raise RuntimeError("citron-emu feature block is malformed")

    block = text[start:end]

    anchor = (
        '    <sharedFeature value="hud_corner" '
        'group="SWITCH OPTIONS" submenu="DISPLAY" />'
    )

    if anchor not in block:
        raise RuntimeError("citron-emu insertion anchor not found")

    addition = '''\
    <feature name="NEXTENDO NETWORK" group="SWITCH OPTIONS" submenu="NETWORK" value="nextendo_network" description="Enable NexTendo network redirection for supported games.">
      <choice name="Disabled" value="false" />
      <choice name="Enabled" value="true" />
    </feature>'''

    block = block.replace(
        anchor,
        anchor + "\n" + addition,
        1,
    )

    new_text = text[:start] + block + text[end:]

    # Some older/generated Switch feature files contain bare "&"
    # characters inside attribute text. Normalize only ampersands that
    # are not already valid XML entities before validation/writing.
    new_text = re.sub(
        r'&(?!#\d+;|#x[0-9A-Fa-f]+;|[A-Za-z_:][A-Za-z0-9_.:-]*;)',
        '&amp;',
        new_text,
    )
    ET.fromstring(new_text)

    tmp = FEATURES.with_suffix(FEATURES.suffix + ".bua-nextendo.tmp")
    tmp.write_text(new_text, encoding="utf-8")
    tmp.replace(FEATURES)

    print("[Nextendo] Added Citron Advanced Game Settings feature.")
    return True


def patch_generator():
    if not GENERATOR.is_file():
        print("[Nextendo] Switch generator not installed; skipping.")
        return False

    text = GENERATOR.read_text(encoding="utf-8")

    if "system.isOptSet('nextendo_network')" in text:
        print("[Nextendo] Citron generator support already present.")
        return False

    anchor = '''\
    # controls section
        if not yuzuConfig.has_section("Controls"):'''

    addition = '''\
    # NexTendo network redirection - Citron only
        if emulator == "citron-emu":
            if not yuzuConfig.has_section("Network"):
                yuzuConfig.add_section("Network")

            if system.isOptSet('nextendo_network'):
                yuzuConfig.set(
                    "Network",
                    "enable_nextendo",
                    system.config["nextendo_network"]
                )
                yuzuConfig.set(
                    "Network",
                    "enable_nextendo\\\\default",
                    "false"
                )

'''

    if anchor not in text:
        raise RuntimeError("Switch generator insertion anchor not found")

    new_text = text.replace(
        anchor,
        addition + anchor,
        1,
    )

    tmp = GENERATOR.with_suffix(GENERATOR.suffix + ".bua-nextendo.tmp")
    tmp.write_text(new_text, encoding="utf-8")

    py_compile.compile(str(tmp), doraise=True)

    tmp.replace(GENERATOR)

    print("[Nextendo] Added Citron generator support.")
    return True


def patch_browser_handoff():
    if not XDG_OPEN.parent.is_dir():
        print(
            "[Nextendo] Switch xdgfix directory not installed; "
            "skipping browser handoff."
        )
        return False

    packaged_selector = Path(__file__).with_name(
        "nextendo-browser-select.py"
    )

    if not packaged_selector.is_file():
        print(
            "[Nextendo] Browser selector helper missing; "
            "skipping browser handoff."
        )
        return False

    selector = XDG_OPEN.parent / "nextendo-browser-select.py"

    selector_text = packaged_selector.read_text(
        encoding="utf-8"
    )

    selector_changed = True

    if selector.is_file():
        current_selector = selector.read_text(
            encoding="utf-8",
            errors="ignore",
        )

        if current_selector == selector_text:
            selector_changed = False

    if selector_changed:
        tmp_selector = selector.with_name(
            "nextendo-browser-select.py.bua-nextendo.tmp"
        )

        tmp_selector.write_text(
            selector_text,
            encoding="utf-8",
        )

        os.chmod(tmp_selector, 0o755)
        tmp_selector.replace(selector)
        os.chmod(selector, 0o755)

    desired = '''#!/bin/sh

export DISPLAY=:0
export XAUTHORITY=/.Xauthority

TARGET="$1"
SELECTOR="/userdata/system/switch/extra/xdgfix/nextendo-browser-select.py"

case "$TARGET" in
    http://*|https://*)
        python3 "$SELECTOR" "$TARGET" \\
            >/tmp/nextendo-browser-selector.log 2>&1 &
        exit 0
        ;;
    *)
        exec pcmanfm "$@"
        ;;
esac
'''

    current = ""

    if XDG_OPEN.is_file():
        current = XDG_OPEN.read_text(
            encoding="utf-8",
            errors="ignore",
        )

    wrapper_changed = current != desired

    if wrapper_changed:
        if XDG_OPEN.is_file():
            backup = XDG_OPEN.with_name(
                "xdg-open.before-nextendo"
            )

            if not backup.exists():
                backup.write_text(
                    current,
                    encoding="utf-8",
                )
                os.chmod(backup, 0o755)

        tmp = XDG_OPEN.with_name(
            "xdg-open.bua-nextendo.tmp"
        )

        tmp.write_text(
            desired,
            encoding="utf-8",
        )

        os.chmod(tmp, 0o755)
        tmp.replace(XDG_OPEN)
        os.chmod(XDG_OPEN, 0o755)

    if not selector_changed and not wrapper_changed:
        print(
            "[Nextendo] OAuth browser selector already configured."
        )
        return False

    print(
        "[Nextendo] Configured OAuth browser selection support."
    )
    return True


def main():
    print("[Nextendo] Checking Switch/Citron integration...")

    steps = [
        ("Advanced Game Settings", patch_features),
        ("Citron generator", patch_generator),
        ("OAuth browser selector", patch_browser_handoff),
    ]

    failures = []

    for label, func in steps:
        try:
            func()
        except Exception as exc:
            failures.append((label, exc))
            print(
                f"[Nextendo] WARNING: {label} integration failed: "
                f"{type(exc).__name__}: {exc}"
            )

    if failures:
        print(
            "[Nextendo] Integration check completed with "
            f"{len(failures)} warning(s)."
        )
    else:
        print("[Nextendo] Integration check complete.")
if __name__ == "__main__":
    main()
