#!/usr/bin/env python3
"""Pure validation of dynamic Switch identities; no networking/installing."""
import hashlib
import json
import re
from urllib.parse import urlsplit, unquote

EXPECTED = {
    "Citron": "/userdata/system/switch/appimages/citron-emu.AppImage",
    "Eden": "/userdata/system/switch/appimages/eden-emu.AppImage",
    "Eden PGO": "/userdata/system/switch/appimages/eden-pgo.AppImage",
    "Eden Nightly": "/userdata/system/switch/appimages/eden-nightly.AppImage",
    "Ryujinx-Nextendo": "/userdata/system/switch/appimages/ryujinx-nextendo.tar.gz",
}

def verify_switch_components(lines, major=42, architecture="x86_64",
                             expected_identity=None, expected_display=None):
    """Match a dynamic, locally bundled switch_identity.py result to targets.

    Accepts the five output lines; rejects opaque, mismatched or static URLs.
    Returns verified component metadata, NEVER an installation authorization.
    """
    if architecture != "x86_64" or major not in (42,43,44):
        raise ValueError("Unsupported Switch component platform")
    if not isinstance(lines, (list,tuple)) or len(lines)!=5:
        raise ValueError("Expected exactly five identity output lines")
    display,identity,source_family,recipe_family,raw_json = lines
    if source_family!="multi_parent" or recipe_family!="switch-components":
        raise ValueError("Unexpected Switch identity source family")
    if not all(isinstance(item,str) and len(item)<15000 for item in lines):
        raise ValueError("Invalid Switch identity fields")
    if len(raw_json)>12000:
        raise ValueError("Oversized Switch identity metadata")
    components=json.loads(raw_json)
    if not isinstance(components,list) or len(components)!=5:
        raise ValueError("Expected five independent Switch components")
    names=[item.get("name") if isinstance(item,dict) else None for item in components]
    if len(set(names))!=5 or set(names)!=set(EXPECTED):
        raise ValueError("Missing or duplicate Switch component")
    canonical=json.dumps({"batocera_major":major,"architecture":architecture,
                          "components":components},sort_keys=True,
                         separators=(",",":")).encode("utf-8")
    calculated="switch:"+str(major)+":components:"+hashlib.sha256(canonical).hexdigest()
    if identity!=calculated:
        raise ValueError("Switch component identity digest mismatch")
    expected_display_value="; ".join(item["name"]+" "+item["version"] for item in components)
    if display!=expected_display_value:
        raise ValueError("Switch display does not match component versions")
    if expected_identity is not None and expected_identity!=identity:
        raise ValueError("Switch identity changed since selection")
    if expected_display is not None and expected_display!=display:
        raise ValueError("Switch version changed since selection")
    checked=[]
    for item in components:
        name=item["name"]
        version=item.get("version")
        url=item.get("url")
        if not isinstance(version,str) or not version or len(version)>128:
            raise ValueError("Invalid component version")
        if not isinstance(url,str) or len(url)>1000:
            raise ValueError("Missing component asset")
        if item.get("target") != EXPECTED[name]:
            raise ValueError("Unexpected component target")
        parsed=urlsplit(url)
        if parsed.scheme!="https" or parsed.username or parsed.password or parsed.port not in (None,443) or parsed.query or parsed.fragment:
            raise ValueError("Unsafe component download URL")
        path=parsed.path
        segments=[unquote(x) for x in path.split("/") if x]
        if any(x in (".","..") or "/" in x or chr(92) in x for x in segments):
            raise ValueError("Unsafe asset URL path")
        host=parsed.hostname
        if name=="Citron":
            if host!="github.com" or not re.fullmatch(
                r"/NextendoNetwork/citron-nextendo/releases/download/nightly-linux/"
                r"citron_nightly-[0-9a-f]+-linux-x86_64(?:_v2|_v3)?[.]AppImage",path):
                raise ValueError("Citron asset not from expected release")
            commit=re.search(r"citron_nightly-([0-9a-f]+)-",path).group(1)
            if version!="nightly-"+commit:
                raise ValueError("Citron commit and version differ")
        elif name=="Ryujinx-Nextendo":
            tag=re.escape(version)
            version_without_v=re.escape(version.removeprefix("v"))
            expected=(r"/NextendoNetwork/Ryujinx-Nextendo/releases/download/"
                      +tag+r"/Nextendo-"+version_without_v+r"-linux-x64[.]tar[.]gz")
            if host!="github.com" or not re.fullmatch(expected,path):
                raise ValueError("Ryujinx asset not from selected release")
        elif name in ("Eden","Eden PGO"):
            variant="gcc-standard" if name=="Eden" else "clang-pgo"
            expected="/"+version+"/Eden-Linux-"+version+"-amd64-"+variant+".AppImage"
            if host!="stable.eden-emu.dev" or path!=expected:
                raise ValueError("Eden stable asset mismatch")
        elif name=="Eden Nightly":
            if "." not in version:
                raise ValueError("Unrecognized Eden nightly version")
            short=version.split(".",1)[1]
            expected="/"+version+"/Eden-Linux-"+short+"-amd64-gcc-standard.AppImage"
            if host!="nightly.eden-emu.dev" or path!=expected:
                raise ValueError("Eden nightly asset mismatch")
        checked.append({"name":name,"version":version,"url":url,
                        "target":EXPECTED[name],"type":"replace_file",
                        "executable":name!="Ryujinx-Nextendo"})
    return {"identity":identity,"display_version":display,
            "components":checked,"validated":True}
