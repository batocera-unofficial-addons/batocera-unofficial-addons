#!/bin/bash
export QT_QPA_PLATFORM=xcb
exec /userdata/system/Desktop/opt/AntiMicroX/antimicrox "$@"
