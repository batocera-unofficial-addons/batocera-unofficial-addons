#!/bin/bash
###
### Batocera.PLUS
### Alexandre Freire dos Santos
###

### Caminhos

ROM="file://${1}"
SAVE_DIR='/userdata/saves/j2me'
FREJ2ME_DIR="$(dirname ${0})"

mkdir -p "${SAVE_DIR}"

### Inicia o AntiMicroX ###

if [ -e '/dev/input/js0' ]; then
    antimicrox --hidden --profile /userdata/system/configs/bat-drl/Freej2me/config/j2me.joystick.amgp &
    ANTIMICROX_PID=$!
fi

### Executa o jogo

java -Dsun.java2d.opengl=True -jar "${FREJ2ME_DIR}/freej2me.jar" "${ROM}"

### Encerra o AntiMicroX ###

if [ -n "${ANTIMICROX_PID}" ]; then
    kill -9 "${ANTIMICROX_PID}"
fi

exit 0
